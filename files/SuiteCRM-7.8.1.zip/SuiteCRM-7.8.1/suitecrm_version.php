<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version      = '7.8.1';
$suitecrm_timestamp    = '2017-02-06 17:00';

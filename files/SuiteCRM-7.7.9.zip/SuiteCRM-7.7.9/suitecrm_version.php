<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version      = '7.7.9';
$suitecrm_timestamp    = '2016-12-31 17:00';